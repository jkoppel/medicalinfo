#ifndef __SEASHELLEXT_H__
#define __SEASHELLEXT_H__

#ifdef _DEBUG
#pragma warning(disable : 4127)
#endif
#pragma warning(disable : 4514)
#pragma warning(disable : 4710)
#pragma warning(disable : 4786)
#pragma warning(disable : 4511 4512)

#include <afxole.h>
#include <afxtempl.h>
#include <afxinet.h>	
#include <afxmt.h>	
#include <atlbase.h>
#include "W2KFix.h"

#define CTRL_EXT_CLASS

#endif //__SEASHELLEXT_H__