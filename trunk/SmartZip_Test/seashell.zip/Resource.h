//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SeaShell.rc
//
#define IDD_ABOUTBOX                    100
#define ID_VIEW_ARRANGE                 127
#define IDR_MAINFRAME                   128
#define IDR_SEASHETYPE                  129
#define IDD_SHELL_TREE                  130
#define IDD_MFC_EXPLORER                132
#define IDD_FILTER                      133
#define IDR_POPUPMENU_LISTCTRL          204
#define IDR_POPUPMENU_HEADERCTRL        205
#define IDR_POPUPMENU_DRAGDROP          208
#define IDR_POPUPMENU_TREE_FOLDER       209
#define IDB_COLDTOOLBAR                 210
#define IDB_HOTTOOLBAR                  211
#define IDC_SHELL_TREE                  1000
#define IDC_ST_PATH                     1001
#define IDC_ST_HELP                     1002
#define IDC_LIST_TEST                   1003
#define IDC_BUTT_PROGRESS               1004
#define IDC_BUTT_NORMAL                 1005
#define IDC_BUTT_DOWNLOAD               1006
#define IDC_TREE_SHELL                  1012
#define IDC_LIST_SHELL                  1013
#define IDC_MFC_BUTT_REPORT             1014
#define IDC_MFC_BUTT_SMALL_ICONS        1015
#define IDC_MFC_BUTT_LARGE_ICONS        1016
#define IDC_MFC_BUTT_DETAILS            1017
#define IDC_COMBO_SHELL                 1018
#define IDC_EDIT_FILTER                 1020
#define IDC_EDIT_FILE_TYPE              1021
#define ID_VIEW_EXPLORERDIALOG          32771
#define ID_VIEW_FILEFILTER              32772
#define ID_VIEW_TREEDIALOG              32773
#define ID_POPUP_DD_MOVE                42768
#define ID_POPUP_DD_COPY                42769
#define ID_POPUP_DD_CANCEL              42770
#define ID_UI_VIEW_LARGE_ICONS          42771
#define ID_UI_VIEW_SMALL_ICONS          42772
#define ID_UI_VIEW_DETAILS              42773
#define ID_UI_VIEW_LIST                 42774
#define ID_UI_VIEW_GRIDLINES            42775
#define ID_UI_VIEW_COLUMN_ORDERING      42778
#define ID_UI_VIEW_FULL_ROW_SELECTION   42779
#define ID_UI_VIEW_TRACK_SELECT         42780
#define ID_UI_VIEW_COLUMN_SIZING        42781
#define ID_HEADER_REMOVE_COL            42782
#define ID_HEADER_EDIT_TEXT             42783
#define ID_HEADER_RESET                 42784
#define ID_UI_VIEW_EDIT_COLUMN          42786
#define ID_POPUP_TF_NEW_FOLDER          42801
#define ID_POPUP_TF_DELETE_FOLDER       42802
#define ID_POPUP_TF_REFRESH             42803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
