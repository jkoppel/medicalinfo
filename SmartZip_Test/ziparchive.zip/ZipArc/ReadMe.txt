ZipArc is a sample application demonstrating features of the ZipArchive library.

Copyright (c) 2000 - 2009 Artpol Software - Tadeusz Dracz

This code may be used in compiled form in any way you desire PROVIDING 
it is not sold for profit as a stand-alone application.

This code may be redistributed unmodified by any means providing it is
not sold for profit without the authors written consent, and
providing that this notice and the authors name and all copyright 
notices remains intact. 

E-Mail: support@artpol-software.com
Web Site: http://www.artpol-software.com/
