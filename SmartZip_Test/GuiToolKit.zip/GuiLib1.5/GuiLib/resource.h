//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GuiLib.rc
//
#define IDI_ARROWDOWN                   2001
#define IDI_ARROWRIGHT                  2002
#define IDB_DOCKBAR                     2004
#define NM_OB_BTNCLICK                  2005
#define WM_BOTTOM_NOTIFY                2006
#define WM_OUTBAR_NOTIFY                2007
#define NM_OB_ITEMCLICK                 2008
#define IDB_BITMAP1                     2008
#define IDB_MDIICONS                    2008
#define WM_TOOL_NOTIFY                  2009
#define IDR_MENUSYS                     2010
#define IDB_BITMAP2                     2019
#define IDB_DOCKBAROFFICE               2019
#define ID_SPINIZ                       2020
#define ID_SPINDE                       2021
#define WM_SHOWTITLE                    2022
#define NCPAINT                         2023
#define SC_CLOSEB                       2024
#define SC_RESTOREB                     2025
#define SC_MINIMIZEB                    2026
#define ID_TOOLUP                       2027
#define ID_TOOLDOWN                     2028
#define IDB_BITMAP3                     2033
#define MNU_SYS                         32778
#define ID_CLOSE                        32999

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2041
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
