// stdafx.cpp : source file that includes just the standard includes
//	Gui_DevStudio.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



