//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Gui_DevStudio.rc
//
#define ADD_NEW_ITEM                    0
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GUI_DETYPE                  129
#define IDB_DBPROJECTS                  130
#define IDR_NEWITEM                     135
#define IDR_MENUNEWITEM                 137
#define IDR_TOOLBARS                    138
#define IDR_MENU1                       140
#define IDR_MENUTOOLBARS                140
#define IDD_DIAL                        141
#define IDD_DIALOG1                     141
#define IDR_MENUNEW                     142
#define IDR_TOOLCOMBOS                  142
#define IDR_MENUTABS                    144
#define ID_WINDOW_ID                    145
#define IDI_ICONHELP                    146
#define IDB_BITMAPHELP                  147
#define IDB_SPLASHVIEW                  148
#define IDC_LIST1                       1000
#define ID_NEW_ITEM                     32772
#define ID_REDO                         32773
#define ID_NAVIBACK                     32774
#define ID_BUTTON32775                  32775
#define ID_START                        32775
#define ID_FINDINFILES                  32776
#define ID_COMBODEBUG                   32777
#define ID_COMBOFIND                    32778
#define ID_SOLUTION                     32779
#define ID_UNDO                         32780
#define ID_EXISTITEM                    32784
#define ID_ADDCLASS                     32785
#define ID_GO                           32786
#define ID_CLASSVIEW                    32786
#define ID_WORKSPACE                    32787
#define ID_OUTPUTNORMAL                 32789
#define ID_OUTPUT                       32790
#define ID_SERVER                       32791
#define ID_COMBO1                       32792
#define ID_COMBO2                       32793
#define ID_COMBO3                       32794
#define ID_VIEW_LOOK_XP                 32795
#define ID_VIEW_LOOK_2003               32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
