// GuiComboFont.cpp: implementation of the CGuiComboFont class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CGuiPowerPoint.h"
#include "GuiComboFont.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGuiComboFont::CGuiComboFont()
{

}

CGuiComboFont::~CGuiComboFont()
{

}
