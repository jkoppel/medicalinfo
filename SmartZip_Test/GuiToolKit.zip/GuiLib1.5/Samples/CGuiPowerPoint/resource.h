//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CGuiPowerPoint.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CGUIPOTYPE                  129
#define IDB_BITPP                       130
#define IDB_FILEVIEW                    131
#define ID_EMAIL                        32771
#define ID_BUSCAR                       32772
#define ID_PREVIEW                      32773
#define ID_BUTTON32774                  32774
#define ID_ORTOGRAFIA                   32775
#define ID_BACK                         32776
#define ID_FORWARD                      32777
#define ID_GRAFICO                      32778
#define ID_TABLA                        32779
#define ID_GRISES                       32780
#define ID_COMBOBOX                     32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
